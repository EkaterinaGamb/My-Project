import { MatchThree } from "./match-three.js";

function startGame() {
    new MatchThree(8, 8, 7);
}

startGame();